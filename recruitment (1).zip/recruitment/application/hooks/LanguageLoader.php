<?php

class LanguageLoader
{
    function initialize() {
        $ci =& get_instance();
        $ci->load->helper('language');
        $language = 'english';

        if ($ci->db->table_exists('languages')) {
            if (strpos(current_url(), 'admin') !== false && adminSession('admin_language')) {
                $language = adminSession('admin_language');
            } elseif (strpos(current_url(), 'admin') != true && candidateLanguage()) {
                $language = candidateLanguage();
            } elseif (strpos(current_url(), 'admin') !== false) {
                $language = objToArr($ci->AdminLanguageModel->getDefault());
                
                $ci->load->library('session');
                if ($ci->session->userdata('admin') && $language) {
                    $adminSession = $ci->session->userdata('admin');
                    $adminSession['admin_language'] = $language['slug'];
                    $adminSession['admin_language_dir'] = $language['direction'];
                    $ci->session->set_userdata('admin',  $adminSession);
                    $language = $language['slug'];
                } else {
                    $language = 'english';
                }
            }
        }

        $ci->lang->load('message', $language);
    }
}