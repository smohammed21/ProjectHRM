  <!--==========================
    Intro Section
  ============================-->
  <?php if (setting('home-banner') == 'yes') { ?>
  <section id="intro" class="clearfix">
    <div class="container">
      <div class="intro-img">
      </div>
      <div class="intro-info">
        <?php echo setting('banner-text'); ?>

        <?php if ($job_filters) { ?>
        <div class="container">
          <div class="row">

          <?php 
            $count = count($job_filters); 
            if ($count == 1) {
              $col = '10';
            } elseif ($count == 2) {
              $col = '5';
            } else {
              $col = '4';
            }
          ?>
          <?php foreach ($job_filters as $filter) { ?>
          
          <div class="col-lg-<?php echo $col; ?>">
          <select class="form-control select2 job-listing-filters-dd-home job-filter"
              data-id="<?php echo encode($filter['job_filter_id']); ?>">
            <option value=""><?php echo esc_output(trimString($filter['title'])); ?></option>
            <?php foreach ($filter['values'] as $v) { ?>
              <option value="<?php echo encode($v['id']); ?>">
                <?php echo esc_output($v['title']); ?>
              </option>
            <?php } ?>
          </select>
          </div>
          <?php } ?>

          <div class="col-lg-2">
            <button class="btn btn-primary btn-sm btn-home-search home-search-btn">
              <i class="fa fa-search" aria-hidden="true"></i> <?php echo lang('search'); ?>
            </button>
          </div>

          </div>
        </div>
        <?php } ?>

      </div>
    </div>
  </section><!-- #intro -->
  <?php } ?>

 

 
