
	<!-- Top Modal -->
	<div class="modal fade in" id="modal-default" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">×</span></button>
	        <h4 class="modal-title">Default Modal</h4>
	      </div>
	      <div class="modal-body-container">
	      </div>
	    </div>
	    <!-- /.modal-content -->
	  </div>
	  <!-- /.modal-dialog -->
	</div>


  <footer class="main-footer">
  	<input type="hidden" id="lang-dir" value="<?php echo adminSession('admin_language_dir'); ?>">
    <strong><?php echo setting('site-name'); ?></strong>
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/admin/js/jquery.min.js"></script>
<!-- jQuery UI -->
<script src="<?php echo base_url(); ?>assets/admin/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/jquery-ui-timepicker-addon.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>assets/admin/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap.min.js"></script>
<!-- Dashboard charts -->
<script src="<?php echo base_url(); ?>assets/admin/js/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/morris.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/Chart.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url(); ?>assets/admin/js/jquery.slimscroll.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/dataTables.bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/iCheck/iCheck.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>assets/admin/js/select2.min.js"></script>
<!-- dropify -->
<script src="<?php echo base_url(); ?>assets/admin/js/dropify.min.js"></script>
<!-- jQuery Multiselect -->
<script src="<?php echo base_url(); ?>assets/admin/js/jquery.multi-select.js"></script>
<!-- CKEditor -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>
<!-- Pill Bar Rating -->
<script src="<?php echo base_url(); ?>assets/admin/js/bar-rating.min.js"></script>
<!-- Bootstrap Toggle -->
<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-toggle.min.js"></script>
<!-- Bootstrap Select -->
<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-select.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/js/adminlte.min.js"></script>
<!-- Candidate Finder Lang -->
<script src="<?php echo base_url(); ?>assets/admin/js/cf/lang.js<?php echo '?v='.strtotime(date('Y-m-d G:i:s')); ?>"></script>
<!-- Candidate Finder App -->
<script src="<?php echo base_url(); ?>assets/admin/js/cf/app.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/cf/general.js"></script>
