<?php if ($candidates) { ?>
<?php foreach ($candidates as $candidate) { ?>
<div class="job-board-candidate-wrap">
  <div class="col-md-4 job-board-candidate-profile">
    <div class="row">
      <div class="col-md-4 job-board-candidate-left">
        <input type="checkbox" class="minimal job-board-candidate-select" 
          data-id="<?php echo esc_output($candidate['candidate_id']); ?>"
          data-resume_id="<?php echo esc_output($candidate['resume_id']); ?>">
        <?php if ($candidate['image']) { ?>
        <img src="<?php echo base_url(); ?>assets/images/candidates/<?php echo esc_output($candidate['image']); ?>" 
            onerror="this.src='<?php echo base_url(); ?>assets/images/candidates/not-found.png'"
            class="job-board-candidate-avatar">
        <?php } else { ?>
        <img src="<?php echo base_url(); ?>assets/images/candidates/not-found.png" 
            class="job-board-candidate-avatar">
        <?php } ?>
      </div>
      <div class="col-md-7 job-board-candidate-right">
        <h2 class="job-board-candidate-name view-resume" data-id="<?php echo esc_output($candidate['resume_id']); ?>"
          title="<?php echo esc_output($candidate['first_name'].' '.$candidate['last_name']); ?>">
          <?php echo trimString($candidate['first_name'].' '.$candidate['last_name'], 13); ?>
        </h2>
        <p class="job-board-candidate-profile-item"><?php echo trimString($candidate['designation'], 30); ?></p>
        <p class="job-board-candidate-profile-item"><?php echo lang('applied_on'); ?> : <?php echo dateFormat($candidate['created_at']); ?></p>

        <?php if ($candidate['resume_type'] == 'detailed') { ?>
        <p class="job-board-candidate-profile-item"><?php echo lang('experience'); ?> : <?php echo esc_output($candidate['experience'], 'html'); ?> Months</p>
        
        <?php } else { ?>
        <a class="btn btn-warning btn-xs" target="_blank" href="<?php echo candidateThumb($candidate['file']); ?>" title="<?php echo lang('download'); ?>">
          <i class="fa fa-file"></i> <?php echo lang('download'); ?>
        </a>
        <?php } ?>
      </div>
    </div>
  </div>
  
  
  
  <div class="col-md-2 job-board-candidate-overall">
    <p class="job-board-candidate-overall-heading"><?php echo lang('overall_result'); ?></p>
    <p class="job-board-candidate-overall-result"><strong><?php 
    echo $candidate['overall_result']; ?>%</strong>
      <br /><span class="job-board-candidate-status job-board-candidate-<?php echo $candidate['status']; ?>"><?php echo lang($candidate['status']); ?></span>
    </p>
  </div>
</div>
<?php } ?>
<?php } else { ?>
<div class="job-board-candidate-wrap">
  <p class="job-board-candidate-wrap-not"><?php echo lang('no_candidates_found'); ?></p>
</div>
<?php } ?>