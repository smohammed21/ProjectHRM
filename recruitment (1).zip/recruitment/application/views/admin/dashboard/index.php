<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i class="fas fa-tachometer-alt"></i> <?php echo lang('dashboard'); ?>
      <small></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fas fa-tachometer-alt"></i> <?php echo lang('home'); ?></a></li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content dashboard-content-wrap">
    <?php if (allowedTo('view_dashboard_stats')) { ?>
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-md-2 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-aqua">
          <div class="inner">
            <h3><?php echo esc_output($jobsCount, 'html'); ?></h3>
            <p><?php echo lang('all_jobs'); ?></p>
          </div>
          <div class="icon">
            <i class="fa fa-suitcase"></i>
          </div>
          <a href="<?php echo base_url(); ?>admin/jobs" class="small-box-footer">
            <?php echo lang('view_all'); ?> <i class="fa fa-arrow-circle-right"></i>
          </a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-md-2 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-yellow">
          <div class="inner">
            <h3><?php echo esc_output($candidates, 'html'); ?></h3>
            <p><?php echo lang('total_candidates'); ?></p>
          </div>
          <div class="icon">
            <i class="fa fa-graduation-cap"></i>
          </div>
          <a href="<?php echo base_url(); ?>admin/candidates" class="small-box-footer">
            <?php echo lang('more_info'); ?> <i class="fa fa-arrow-circle-right"></i>
          </a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-md-2 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-primary">
          <div class="inner">
            <h3><?php echo esc_output($applications, 'html'); ?></h3>
            <p><?php echo lang('total_applications'); ?></p>
          </div>
          <div class="icon">
            <i class="fas fa-hand-paper"></i>
          </div>
          <a href="<?php echo base_url(); ?>admin/job-board" class="small-box-footer">
            <?php echo lang('more_info'); ?> <i class="fa fa-arrow-circle-right"></i>
          </a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-md-2 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-maroon">
          <div class="inner">
            <h3><?php echo esc_output($interviews, 'html'); ?></h3>
            <p><?php echo lang('total_interviews'); ?></p>
          </div>
          <div class="icon">
            <i class="fas fa-gavel"></i>
          </div>
          <a href="<?php echo base_url(); ?>admin/candidate-interviews" class="small-box-footer">
            <?php echo lang('more_info'); ?> <i class="fa fa-arrow-circle-right"></i>
          </a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-md-2 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-green">
          <div class="inner">
            <h3><?php echo esc_output($hired, 'html'); ?></h3>
            <p><?php echo lang('total_hired'); ?></p>
          </div>
          <div class="icon">
            <i class="fa fa-check"></i>
          </div>
          <a href="<?php echo base_url(); ?>admin/job-board" class="small-box-footer">
            <?php echo lang('more_info'); ?> <i class="fa fa-arrow-circle-right"></i>
          </a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-md-2 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-red">
          <div class="inner">
            <h3><?php echo esc_output($rejected, 'html'); ?></h3>
            <p><?php echo lang('total_rejected'); ?></p>
          </div>
          <div class="icon">
            <i class="fas fa-times-circle"></i>
          </div>
          <a href="<?php echo base_url(); ?>admin/job-board" class="small-box-footer">
            <?php echo lang('more_info'); ?> <i class="fa fa-arrow-circle-right"></i>
          </a>
        </div>
      </div>
    </div>
    <?php } ?>
    <!-- /.row -->


  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Forms for actions -->
<form id="jobs_data_form"></form>
<form id="jobs_list_form"></form>
<form id="todos_list_form"></form>
<form id="candidates_data_form"></form>

<?php include(VIEW_ROOT.'/admin/layout/footer.php'); ?>

<!-- page script -->
<script src="<?php echo base_url(); ?>assets/admin/js/cf/dashboard.js"></script>

</body>
</html>

