<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1><i class="fa fa-briefcase"></i> <?php echo lang('jobs'); ?><small></small></h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url(); ?>admin/dashboard"><i class="fas fa-tachometer-alt"></i> <?php echo lang('home'); ?></a></li>
      <li class="active"><i class="fa fa-briefcase"></i> <?php echo lang('job'); ?></li>
      <li class="active"><?php echo lang('create'); ?></li>
    </ol>
  </section>

    <!-- Main content -->
    <section class="content job-create-edit">
      <div class="row">

        <?php if (allowedTo('create_jobs') || allowedTo('edit_jobs')) { ?>
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo lang('details'); ?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" id="admin_job_create_update_form">
              <div class="box-body">
                <div class="row">
                  <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo lang('title'); ?></label>
                      <input type="hidden" name="job_id" value="<?php echo esc_output($job['job_id']); ?>" />
                      <input type="text" class="form-control" placeholder="<?php echo lang('enter_title'); ?>" name="title" 
                      value="<?php echo esc_output($job['title']); ?>">
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo lang('status'); ?></label>
                      <select class="form-control">
                        <option value="1" <?php sel($job['status'], 1); ?>><?php echo lang('active'); ?></option>
                        <option value="0" <?php sel($job['status'], 0); ?>><?php echo lang('inactive'); ?></option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                      <label>
                        <?php echo lang('departments'); ?>
                        <button type="button" class="btn btn-xs btn-warning btn-blue create-or-edit-department" data-id="" 
                        title="Add New Department">
                          <i class="fa fa-plus"></i>
                        </button>
                      </label>
                      <select class="form-control select2" id="departments" name="department_id">
                        <option value=""><?php echo lang('none'); ?></option>
                        <?php foreach ($departments as $key => $value) { ?>
                          <option value="<?php echo esc_output($value['department_id']); ?>" <?php sel($job['department_id'], $value['department_id']); ?>><?php echo esc_output($value['title'], 'html'); ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo lang('is_static_allowed'); ?></label>
                      <select class="form-control" name="is_static_allowed">
                        <option value="0" <?php sel($job['is_static_allowed'], 0); ?>><?php echo lang('no'); ?></option>
                        <option value="1" <?php sel($job['is_static_allowed'], 1); ?>><?php echo lang('yes'); ?></option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label><?php echo lang('description'); ?></label>
                      <textarea id="description" name="description" rows="10" cols="80">
                        <?php echo esc_output($job['description'], 'textarea'); ?>
                      </textarea>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <hr />
                  </div>

                  <?php if ($job_filters) { ?>
                  <?php foreach ($job_filters as $filter) { ?>
                  <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo esc_output($filter['title']); ?></label>
                      <select class="form-control select2" id="<?php echo esc_output($filter['job_filter_id']); ?>" 
                          name="filters[<?php echo esc_output($filter['job_filter_id']); ?>][]" multiple="multiple">
                        <?php foreach ($filter['values'] as $v) { ?>
                          <?php $sel = sel2($filter['job_filter_id'], $job['job_filter_ids'], $v['id'], $job['job_filter_value_ids']); ?>
                          <option value="<?php echo esc_output($v['id']); ?>" <?php echo esc_output($sel); ?>><?php echo esc_output($v['title']); ?>
                          </option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <?php } ?>
                  <?php } else { ?>
                  <div class="row resume-item-edit-box-section">
                    <div class="col-md-12 col-lg-12">
                      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo lang('no_job_filters'); ?></p>
                    </div>
                  </div>
                  <?php } ?>

                  
                  
                  
                  
                  
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary" id="admin_job_create_update_form_button">
                  <?php echo lang('save'); ?>
                </button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <?php } ?>

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include(VIEW_ROOT.'/admin/layout/footer.php'); ?>

<!-- page script -->
<script src="<?php echo base_url(); ?>assets/admin/js/cf/company.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/cf/department.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/cf/job.js"></script>

</body>
</html>

