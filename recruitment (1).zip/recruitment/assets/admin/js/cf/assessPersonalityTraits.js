async function extractTextFromPdf(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = function(event) {
        const arrayBuffer = event.target.result;
        const uint8Array = new Uint8Array(arrayBuffer);
        pdfjsLib.getDocument({ data: uint8Array }).promise
          .then(pdf => {
            let text = '';
            const numPages = pdf.numPages;
            const getPageText = (pageNumber) => {
              pdf.getPage(pageNumber).then(page => {
                page.getTextContent().then(content => {
                  content.items.forEach(item => {
                    text += item.str + '\n';
                  });
                  if (pageNumber < numPages) {
                    getPageText(pageNumber + 1); // Recursive call for next page
                  } else {
                    resolve(text);
                  }
                });
              });
            };
            getPageText(1); // Start from the first page
          })
          .catch(error => {
            reject(error);
          });
      };
      reader.onerror = function(error) {
        reject(error);
      };
      reader.readAsArrayBuffer(file);
    });
  }
  
  function assessPersonalityTraits(cvContent) {
    const communicationKeywords = ["communicate", "collaborate", "express", "written communication", "verbal communication", "presentation skills", "mobile", "email", "address", "contact"];
    const leadershipKeywords = ["lead", "manage", "delegate", "teamwork", "collaboration", "decision-making", "problem-solving", "time management", "strategic planning", "motivational skills", "leadership", "project management"];
    const attentionToDetailKeywords = ["meticulous", "accuracy", "precise", "accuracy", "precision", "thoroughness", "skills", "programming language", "AutoCAD", "RDBMS", "MS Office", "quick learner", "hard working", "eager to learn", "self-motivated", "flexible"];
  
    const communicationScore = calculateScore(cvContent.split(/\s+/), communicationKeywords);
    const leadershipScore = calculateScore(cvContent.split(/\s+/), leadershipKeywords);
    const attentionToDetailScore = calculateScore(cvContent.split(/\s+/), attentionToDetailKeywords);
  
    const communicationWeight = 0.5;
    const leadershipWeight = 0.3;
    const attentionToDetailWeight = 0.2;
  
    const communicationTraitScore = communicationScore * communicationWeight;
    const leadershipTraitScore = leadershipScore * leadershipWeight;
    const attentionToDetailTraitScore = attentionToDetailScore * attentionToDetailWeight;
  
    const overallScore = communicationTraitScore + leadershipTraitScore + attentionToDetailTraitScore;
  
    const report = {
      "Communication Skills": {
        "Score": communicationTraitScore,
        "Keywords": communicationKeywords,
        "Occurrences": communicationScore
      },
      "Leadership Skills": {
        "Score": leadershipTraitScore,
        "Keywords": leadershipKeywords,
        "Occurrences": leadershipScore
      },
      "Attention to Detail": {
        "Score": attentionToDetailTraitScore,
        "Keywords": attentionToDetailKeywords,
        "Occurrences": attentionToDetailScore
      },
      "Overall Score": overallScore
    };
  
    return report;
  }
  
  function calculateScore(tokens, traitKeywords) {
    const keywordMatches = tokens.filter(token => traitKeywords.includes(token.toLowerCase()));
    return keywordMatches.length;
  }
  
  async function handleUpload() {
    const fileInput = document.getElementById('cvFile');
    const file = fileInput.files[0];
  
    if (file) {
      try {
        const cvText = await extractTextFromPdf(file);
        const result = assessPersonalityTraits(cvText);
        console.log(result); // Display or handle the results as needed
      } catch (error) {
        console.error('Error extracting text from PDF:', error);
      }
    } else {
      console.error('No file selected');
    }
  }
  